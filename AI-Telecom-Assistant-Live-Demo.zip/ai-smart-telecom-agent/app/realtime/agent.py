from app.realtime.understanding import understand
from app.realtime.rasa_client import RasaClient

RESPONSES = {
    "ctc": "CTC (Centralized Traffic Control) supervises and controls train movements from a control center. In a railway telecom architecture, it typically depends on resilient IP networking, control-center services and operational communications.",
    "pis": "PIS (Passenger Information System) distributes passenger-facing information such as destinations, arrivals, departures and service messages. A robust design normally considers availability, network segmentation and integration with the control system.",
    "gsm_r": "GSM-R is a railway-specific mobile communication system used for operational voice and data. For a telecom engineer, key areas include radio coverage, core network, transmission, QoS and railway operational interfaces.",
    "frMCS": "FRMCS is the next-generation railway mobile communication framework intended to succeed GSM-R, with stronger support for mission-critical broadband services and 5G-based capabilities.",
    "network_issue": "For a network issue, I would start with: 1) service reachability, 2) Layer-2 state/VLAN, 3) Layer-3 routing, 4) latency/loss, 5) interface and transport alarms, then correlate with NMS/packet captures.",
    "sip": "For SIP troubleshooting, inspect the signaling sequence first: INVITE → provisional response → final response → ACK, then media negotiation/SDP and RTP. For failures, correlate SIP codes, Via/Contact/Call-ID and network reachability.",
    "architecture": "This demo follows a reusable flow: client → WebSocket/API → session → understanding (Rasa optional) → agent decision → response. File input follows detection → validation → processing.",
    "help": "I can demonstrate railway telecom concepts (CTC, PIS, GSM-R, FRMCS), SIP/VoIP troubleshooting, network diagnostics, architecture questions, and PDF/image input processing.",
    "greet": "Hello. I’m the AI Telecom Assistant. Ask me about CTC, PIS, GSM-R, FRMCS, SIP/VoIP, network troubleshooting or the system architecture.",
    "goodbye": "Goodbye.",
    "general": "I can analyze that as a telecom question. Try a specific topic such as “Explain CTC”, “Troubleshoot packet loss”, “Analyze a SIP call flow”, or “Explain the architecture”.",
}

async def process_message(message: str, session, rasa_client: RasaClient | None = None) -> dict:
    rasa_client = rasa_client or RasaClient()
    understanding = await rasa_client.parse(message, session.session_id)
    if understanding is None:
        understanding = understand(message)
        understanding["source"] = "local"

    session.conversation.append({
        "role": "user",
        "content": message,
        "understanding": understanding,
    })

    intent = understanding["intent"]
    response = RESPONSES.get(intent, RESPONSES["general"])
    session.conversation.append({"role": "assistant", "content": response})

    return {
        "type": "agent_response",
        "session_id": session.session_id,
        "response": response,
        "intent": intent,
        "confidence": round(float(understanding.get("confidence", 0.0)), 3),
        "entities": understanding.get("entities", {}),
        "source": understanding.get("source", "local"),
    }
