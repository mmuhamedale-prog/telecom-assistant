import re

INTENTS = {
    "greet": ["hello", "hi", "hey", "good morning", "good afternoon"],
    "goodbye": ["bye", "goodbye", "see you"],
    "ctc": ["ctc", "centralized traffic control", "traffic control"],
    "pis": ["pis", "passenger information", "passenger display", "display system"],
    "gsm_r": ["gsm-r", "gsm r", "railway radio"],
    "frMCS": ["frmc", "frmcS", "future railway mobile"],
    "network_issue": ["network down", "no signal", "link down", "packet loss", "connection down", "network problem"],
    "sip": ["sip", "voip", "call flow", "invite", "bye message"],
    "architecture": ["architecture", "layer 2", "layer 3", "layer 7", "api", "websocket"],
    "help": ["what can you do", "help", "capabilities"],
}

def understand_locally(message: str) -> dict:
    text = message.strip().lower()
    scores = {}
    for intent, phrases in INTENTS.items():
        scores[intent] = max(
            (1.0 if phrase in text else 0.0) for phrase in phrases
        )
    intent = max(scores, key=scores.get)
    confidence = scores[intent]
    if confidence == 0:
        intent = "general"
        confidence = 0.42

    entities = {}
    for system in ["CTC", "PIS", "GSM-R", "FRMCS", "SIP", "VoIP", "MPLS", "SCADA"]:
        if system.lower() in text:
            entities["system"] = system

    return {
        "intent": intent,
        "confidence": confidence,
        "entities": entities,
    }

understand = understand_locally
