"""Small Rasa REST client used by the existing realtime agent.

Rasa is optional at runtime. The agent falls back to the original local
understanding rules when the Rasa server is unavailable.
"""

import os
from typing import Any

import httpx


class RasaClient:
    def __init__(self, base_url: str | None = None, timeout: float = 5.0):
        self.base_url = (base_url or os.getenv("RASA_URL", "")).rstrip("/")
        self.timeout = timeout

    @property
    def enabled(self) -> bool:
        return bool(self.base_url)

    async def parse(self, message: str, sender_id: str) -> dict[str, Any] | None:
        if not self.enabled:
            return None

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/model/parse",
                    json={"text": message, "sender": sender_id},
                )
                response.raise_for_status()
                payload = response.json()
        except (httpx.HTTPError, ValueError):
            return None

        intent = payload.get("intent") or {}
        entities = {}
        for entity in payload.get("entities") or []:
            name = entity.get("entity")
            if name:
                entities[name] = entity.get("value")

        return {
            "intent": intent.get("name", "general"),
            "confidence": intent.get("confidence", 0.0),
            "entities": entities,
            "text": payload.get("text", message),
            "source": "rasa",
        }