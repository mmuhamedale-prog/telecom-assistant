from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class RealtimeSession:
    session_id: str
    connected_at: datetime = field(default_factory=datetime.utcnow)
    conversation: list[dict] = field(default_factory=list)
    active: bool = True

sessions: dict[str, RealtimeSession] = {}

def create_session(current_session_id: str) -> RealtimeSession:
    session = RealtimeSession(session_id=current_session_id)
    sessions[current_session_id] = session
    return session

def get_session(current_session_id: str) -> RealtimeSession | None:
    return sessions.get(current_session_id)

def remove_session(current_session_id: str) -> None:
    sessions.pop(current_session_id, None)
