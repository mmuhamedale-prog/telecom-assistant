from uuid import uuid4
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.realtime.session import create_session, remove_session
from app.realtime.agent import process_message
from app.realtime.rasa_client import RasaClient

router = APIRouter()

@router.websocket("/ws")
async def realtime_endpoint(client_websocket: WebSocket):
    await client_websocket.accept()
    current_session_id = str(uuid4())
    session = create_session(current_session_id)
    await client_websocket.send_json({
        "type": "session_started",
        "session_id": current_session_id,
        "message": "Realtime telecom session established."
    })
    rasa_client = RasaClient()
    try:
        while True:
            message = await client_websocket.receive_text()
            result = await process_message(message, session, rasa_client)
            await client_websocket.send_json(result)
    except WebSocketDisconnect:
        session.active = False
        remove_session(current_session_id)
