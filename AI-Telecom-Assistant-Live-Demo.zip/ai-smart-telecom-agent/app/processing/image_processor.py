from io import BytesIO
from PIL import Image
import pytesseract

def process_image(file_bytes: bytes) -> str:
    image = Image.open(BytesIO(file_bytes))
    return pytesseract.image_to_string(image)
