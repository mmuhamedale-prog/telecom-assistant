from pathlib import Path
from app.input.validators.image_validator import validate_image
from app.input.validators.pdf_validator import validate_pdf

def validate_file(file, detected_type: str, file_bytes: bytes):
    extension = Path(file.filename or "").suffix.lower()
    expected_extensions = {
        "pdf": [".pdf"],
        "image": [".jpg", ".jpeg", ".png"],
    }
    if extension not in expected_extensions.get(detected_type, []):
        raise ValueError("Filename extension does not match detected file type")
    if detected_type == "image":
        validate_image(file_bytes)
    elif detected_type == "pdf":
        validate_pdf(file_bytes)
    else:
        raise ValueError("No validator available for this file type")
    return True
