from io import BytesIO
from PIL import Image

def validate_image(file_bytes: bytes) -> bool:
    try:
        image = Image.open(BytesIO(file_bytes))
        image.verify()
    except Exception as exc:
        raise ValueError("Invalid image file") from exc
    return True
