from io import BytesIO
from pypdf import PdfReader

def validate_pdf(file_bytes: bytes) -> bool:
    try:
        PdfReader(BytesIO(file_bytes))
    except Exception as exc:
        raise ValueError("Invalid PDF file") from exc
    return True
