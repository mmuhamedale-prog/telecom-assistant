def detect_file_type(file_bytes: bytes) -> str:
    if file_bytes.startswith(b"%PDF"):
        return "pdf"
    if file_bytes.startswith(b"\xFF\xD8\xFF"):
        return "image"
    if file_bytes.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image"
    raise ValueError("Unsupported file type")
