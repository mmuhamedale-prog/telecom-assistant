from app.processing.image_processor import process_image
from app.processing.pdf_processor import process_pdf

def process_file(file_bytes: bytes, detected_type: str):
    if detected_type == "image":
        return process_image(file_bytes)
    if detected_type == "pdf":
        return process_pdf(file_bytes)
    raise ValueError("No processor available for this file type")
