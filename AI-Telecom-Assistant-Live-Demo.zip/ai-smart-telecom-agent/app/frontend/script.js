const protocol=location.protocol==="https:"?"wss":"ws";
const socket=new WebSocket(`${protocol}://${location.host}/ws`);
const $=id=>document.getElementById(id);
const messages=$("messages");

socket.onopen=()=>{ $("status").textContent="Connected"; $("dot").style.background="#35d39b"; $("mConnection").textContent="ONLINE"; };
socket.onclose=()=>{ $("status").textContent="Disconnected"; $("dot").style.background="#ef6464"; $("mConnection").textContent="OFFLINE"; };
socket.onerror=()=>{ $("status").textContent="Connection error"; };

socket.onmessage=e=>{
  const d=JSON.parse(e.data);
  if(d.type==="session_started"){ $("session").textContent=`Session ${d.session_id.slice(0,8)}…`; return; }
  addMessage("agent",d.response);
  $("mIntent").textContent=d.intent||"—";
  $("mConfidence").textContent=d.confidence!=null?`${Math.round(d.confidence*100)}%`:"—";
  $("mSource").textContent=d.source||"—";
  $("mEntities").textContent=Object.keys(d.entities||{}).join(", ")||"None";
};

function addMessage(kind,text){
  const el=document.createElement("div"); el.className=`msg ${kind}`; el.textContent=text;
  messages.appendChild(el); messages.scrollTop=messages.scrollHeight;
}
function send(text){
  text=(text||$("message").value).trim();
  if(!text||socket.readyState!==WebSocket.OPEN)return;
  addMessage("user",text); socket.send(text); $("message").value="";
}
$("send").onclick=()=>send();
$("message").onkeydown=e=>{if(e.key==="Enter")send()};
document.querySelectorAll(".quick").forEach(b=>b.onclick=()=>send(b.dataset.q));
$("clear").onclick=()=>{messages.innerHTML="";};

$("file").onchange=async e=>{
  const file=e.target.files[0]; if(!file)return;
  $("fileStatus").textContent=`Processing ${file.name}…`;
  const fd=new FormData(); fd.append("file",file);
  try{
    const r=await fetch("/input/upload",{method:"POST",body:fd});
    const d=await r.json(); if(!r.ok)throw new Error(d.detail||"Upload failed");
    addMessage("user",`Uploaded: ${file.name}`);
    addMessage("agent",`Detected ${d.detected_type.toUpperCase()}.\n\n${d.result||"Processed successfully."}`);
    $("fileStatus").textContent=`Processed · ${d.detected_type}`;
  }catch(err){ addMessage("agent",`Upload error: ${err.message}`); $("fileStatus").textContent="Upload failed"; }
  e.target.value="";
};
