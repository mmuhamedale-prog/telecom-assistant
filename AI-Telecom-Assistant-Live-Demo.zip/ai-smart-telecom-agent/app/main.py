from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.api.input import router as input_router
from app.realtime.websocket import router as realtime_router

app = FastAPI(
    title="AI Telecom Assistant",
    version="1.0.0",
    description="Recruiter-ready realtime AI telecom demonstration.",
)

app.include_router(input_router)
app.include_router(realtime_router)

FRONTEND_DIR = Path(__file__).parent / "frontend"
app.mount("/frontend", StaticFiles(directory=FRONTEND_DIR), name="frontend")

@app.get("/")
async def root():
    return FileResponse(FRONTEND_DIR / "index.html")

@app.get("/health")
async def health():
    return {"status": "OK", "service": "AI Telecom Assistant"}

@app.get("/api/demo-info")
async def demo_info():
    return {
        "service": "AI Telecom Assistant",
        "realtime": True,
        "websocket": "/ws",
        "input_api": "/input/upload",
        "understanding": "Rasa optional; local fallback enabled",
        "domains": ["Railway Telecom", "CTC", "PIS", "GSM-R", "FRMCS", "SIP/VoIP", "IP Networking"],
    }
