from fastapi import APIRouter, UploadFile, File, HTTPException

from app.input.detector import detect_file_type
from app.input.validators.file_validator import validate_file
from app.services.processing_service import process_file

router = APIRouter(prefix="/input", tags=["Input"])
MAX_FILE_SIZE = 10 * 1024 * 1024

@router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    file_bytes = await file.read(MAX_FILE_SIZE + 1)
    if len(file_bytes) > MAX_FILE_SIZE:
        raise HTTPException(413, "File exceeds the 10 MB demo limit.")
    try:
        detected_type = detect_file_type(file_bytes)
        validate_file(file, detected_type, file_bytes)
        result = process_file(file_bytes, detected_type)
        return {
            "filename": file.filename,
            "detected_type": detected_type,
            "size_bytes": len(file_bytes),
            "result": result[:12000] if isinstance(result, str) else result,
        }
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except Exception as exc:
        raise HTTPException(500, f"Processing failed: {exc}") from exc
