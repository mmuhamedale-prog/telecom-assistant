# AI Telecom Assistant — Live Demo

A recruiter-facing technical demonstration of a realtime AI telecom assistant.

## What the demo shows

- **Realtime WebSocket communication**
- **Session lifecycle and conversation state**
- **Rasa-compatible NLU with local fallback**
- **Intent + confidence + entity telemetry**
- **Railway telecom knowledge scenarios:** CTC, PIS, GSM-R, FRMCS
- **SIP / VoIP troubleshooting scenario**
- **Universal input pipeline:** detection → validation → processing
- **PDF text extraction and image OCR**
- **FastAPI REST + WebSocket interfaces**
- Clean frontend requiring no separate frontend build step

## Run locally

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Open `http://localhost:8000`.

The demo works **without Rasa**. If Rasa is available, set:

```bash
RASA_URL=http://localhost:5005
```

Then start Rasa separately.

## Docker

```bash
docker build -t ai-telecom-agent .
docker run -p 8000:8000 ai-telecom-agent
```

Open `http://localhost:8000`.

## API

- `GET /health`
- `GET /api/demo-info`
- `POST /input/upload`
- `WS /ws`
- Interactive API docs: `/docs`

## Suggested recruiter demo

1. Open the dashboard.
2. Ask **“Explain the CTC system.”**
3. Ask **“How would you troubleshoot packet loss?”**
4. Ask **“Explain a SIP call flow.”**
5. Upload a PDF or image.
6. Point out the live intent, confidence, entity and NLU-source telemetry.
7. Explain that Rasa can be enabled without changing the realtime interface.

## Architecture

```text
Browser
   │
   ├── WebSocket ──> Session ──> Understanding ──> Agent ──> Response
   │                    │             │
   │                    │             └── Rasa (optional)
   │                    │                 Local fallback
   │
   └── REST Upload ──> Detection ──> Validation ──> Processing
```

This is intentionally a **demo-ready baseline**, not a production telecom control system. External network automation, live SIP capture, authentication and production observability should be added only when the corresponding backend integrations are available.
